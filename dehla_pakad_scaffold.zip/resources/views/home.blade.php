@extends('layouts.app')
@section('title','Dehla Pakad — Collect the Tens')
@section('content')
<section class='brand-grad py-5'><div class='container'><div class='row align-items-center g-4'><div class='col-lg-7'><h1 class='display-5 fw-bold'>Dehla Pakad</h1><p class='lead text-secondary'>Team up, follow suit, and <span class='text-white fw-semibold'>collect the tens</span>.</p><div class='d-flex gap-3'><a href='{{ url('/play') }}' class='btn btn-brand btn-lg'>Play Now</a><a href='{{ url('/about') }}' class='btn btn-outline-light btn-lg'>About</a></div></div><div class='col-lg-5'><div class='card p-4'><h5 class='mb-3'>Quick Start</h5><ol class='mb-0'><li>Create a room</li><li>Deal 5, decide trump</li><li>Play anticlockwise</li><li>Two tricks in a row to take centre pile</li></ol></div></div></div></div></section>
@endsection
