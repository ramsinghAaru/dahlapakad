@extends('layouts.app')
@section('title','Privacy Policy — Dehla Pakad')
@section('content')
<section class='py-5'><div class='container'><h1 class='mb-4'>Privacy Policy</h1><p>Last updated: {{ date('F d, Y') }}</p></div></section>
@endsection
