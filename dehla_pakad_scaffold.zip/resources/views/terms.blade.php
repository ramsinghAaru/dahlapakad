@extends('layouts.app')
@section('title','Terms & Conditions — Dehla Pakad')
@section('content')
<section class='py-5'><div class='container'><h1 class='mb-4'>Terms & Conditions</h1><p>Last updated: {{ date('F d, Y') }}</p></div></section>
@endsection
