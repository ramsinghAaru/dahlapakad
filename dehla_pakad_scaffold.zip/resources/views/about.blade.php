@extends('layouts.app')
@section('title','About — Dehla Pakad')
@section('content')
<section class='py-5'><div class='container'><h1 class='mb-4'>About</h1><p class='text-secondary'>Classic trick‑taking game. Built with Laravel + Bootstrap + Three.js.</p></div></section>
@endsection
