Dehla Pakad scaffold. Copy into a real Laravel app and run migrations.
